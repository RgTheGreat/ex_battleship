# ex_battleship
ex_battleship is a package to play battleship
